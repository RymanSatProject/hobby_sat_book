#coding: utf-8
"""
衛星側チャットシステム　共通設定
"""

import pathlib

# チャットシステム部のルートパス
PATH_ROOT = str(pathlib.Path(__file__).parent.parent.resolve())