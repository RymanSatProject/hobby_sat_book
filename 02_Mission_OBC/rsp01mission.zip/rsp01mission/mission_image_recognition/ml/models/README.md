# main.tflite
https://drive.google.com/uc?export=download&id=1fP_KVUDkrC_2WKm5vrmWGHEHJZXq2UaA

# main.h5
https://drive.google.com/uc?export=download&id=16k4LXLy7yFlx29m7owAK38hsaKZoinhL
