## 概要
Raspberry Pi上で動作するMission系のカメラ機能。自撮りや画像等の送信を行う。

## 必要なもの
pillowに以下のライブラリが必要
```
sudo apt-get install libopenjp2-7
```

## コーディング規則
- 文字コードはUTF-8とする。
- IntelliJ IDEAでオートフォーマットをかけるのをおすすめします。Option + Cmd + L(WindowsではAlt + Ctrl + L)
